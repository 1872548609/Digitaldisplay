#ifndef OSAL_DEBUG_H
#define OSAL_DEBUG_H

void Uart_Debug_SendString(const char *pt);

#endif