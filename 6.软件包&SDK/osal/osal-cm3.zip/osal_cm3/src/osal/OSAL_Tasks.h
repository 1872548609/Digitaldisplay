#ifndef OSAL_TASKS_H
#define OSAL_TASKS_H

/*********************************************************************
    Filename:       OSAL_Tasks.h
    Revised:        $Date: 2008/09/20 $
    Revision:       $Revision: 0.10 $
    
    Description:    
    
       This file contains the OSAL Task definition and manipulation
       functions.
            
*********************************************************************/

#ifdef __cplusplus
extern "C"
{
#endif

/*********************************************************************
 * INCLUDES
 */
 
/*********************************************************************
 * MACROS
 */

/*********************************************************************
 * CONSTANTS
 */
#define TASK_NO_TASK      0xFF

 
/*********************************************************************
 * TYPEDEFS
 */
/*
 * Task Initialization function prototype
 */
typedef void (*pTaskInitFn)( unsigned char task_id );
 
/*
 * Event handler function prototype
 */
typedef void (*pTaskEventHandlerFn)( unsigned char task_id, unsigned short event );
 
typedef struct 
#ifdef __GNUC__
__attribute__ ((packed))
#endif
{
  pTaskInitFn pfnInit;
  pTaskEventHandlerFn pfnEventProcessor;
  byte   taskID;
  uint16 events;
  void  *next;
} osalTaskRec_t;


/*********************************************************************
 * GLOBAL VARIABLES
 */
extern osalTaskRec_t *activeTask;
 
/*********************************************************************
 * FUNCTIONS
 */

/*
 * Initialization for the Tasking System.
 */
extern void osalTaskInit( void );

/*
 *  Add a task to the task list
 */
extern void osalTaskAdd( const pTaskInitFn pfnInit, 
                  const pTaskEventHandlerFn pfnEventProcessor );

/*
 * Call each of the tasks initailization functions.
 */
extern void osalInitTasks( void );

/*
 * This function will return the next active task.
 */
extern osalTaskRec_t *osalNextActiveTask( void );

/*
 * This function will return a task pointer to the task
 *       found with the passed in task ID.
 */
extern osalTaskRec_t *osalFindTask( byte taskID );

/*********************************************************************
*********************************************************************/

#ifdef __cplusplus
}
#endif

#endif /* OSAL_TASKS_H */
